num1=input("enter the first interger number ")
num2-input("enter the second interger numner")
sum= int(num1)+int(num2)
print(sum)